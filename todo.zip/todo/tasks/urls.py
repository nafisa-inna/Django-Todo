from django.urls import path
from .views import TaskListCreate, TaskRetrieveUpdateDelete, index, favicon_view

urlpatterns = [
    path('', index, name='index'),
    path('tasks/', TaskListCreate.as_view(), name='task-list-create'),
    path('tasks/<int:pk>/', TaskRetrieveUpdateDelete.as_view(), name='task-detail-update-delete'),
    path('favicon.ico', favicon_view, name='favicon'),  # Add this line
]
