from rest_framework import generics, status
from rest_framework.response import Response
from .models import Task
from .serializers import TaskSerializer
from django.shortcuts import render
from django.http import HttpResponse
from rest_framework.decorators import api_view
from django.views.decorators.http import require_GET

def index(request):
    return render(request, 'index.html')

class TaskListCreate(generics.ListCreateAPIView):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer

    def perform_create(self, serializer):
        serializer.save()

class TaskRetrieveUpdateDelete(generics.RetrieveUpdateDestroyAPIView):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer

@require_GET
def favicon_view(request):
    # Replace the below with the actual binary data of your favicon
    favicon_data = b"""<binary data of your favicon goes here>"""  # TODO: Add favicon binary data
    return HttpResponse(favicon_data, content_type="image/x-icon")

@api_view(['POST'])
def create_task(request):
    print("Received data:", request.data)  # Log incoming data
    serializer = TaskSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    print("Validation errors:", serializer.errors)  # Log serializer errors
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
